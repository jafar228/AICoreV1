import json,maskpass
from path import ascii, check_sound, cmd_commands


with open("base.json", "r", encoding="utf-8") as file:
    data = json.load(file)


users = data["users"]
settings = data["settings"]

print(ascii)
cmd = 0

login = input("Enter your Login:").lower()
password = maskpass.askpass(prompt="Enter your Password:", mask="*").lower()

for user in users:
    if login == user["name"] and password == user["password"]:
        print(f"Welcome,{login}")
        cmd = 1
        check_sound("succes.wav", settings)
        break
else:
    print(f"Unknow {login} user")


commands = cmd_commands(user,data,settings)

while cmd:
    command = input("Enter commnad > ").lower()

    if command in commands:
        commands[command]()

    if command == "exit":
        cmd = False
        print("You did exit in cmd mode.Program off")