import json,os,time
from playsound3 import playsound


ascii = """
    /$$$$$            /$$$$$$                 /$$                       /$$$$$$             /$$$$$$   /$$    
   |__  $$           /$$__  $$                \ $                      /$$__  $$           /$$__  $$ | $$    
      | $$  /$$$$$$ | $$  \__//$$$$$$   /$$$$$$\/ /$$$$$$$            | $$  \__/  /$$$$$$ | $$  \__//$$$$$$  
      | $$ |____  $$| $$$$   |____  $$ /$$__  $$ /$$_____/            |  $$$$$$  /$$__  $$| $$$$   |_  $$_/  
 /$$  | $$  /$$$$$$$| $$_/    /$$$$$$$| $$  \__/|  $$$$$$              \____  $$| $$  \ $$| $$_/     | $$    
| $$  | $$ /$$__  $$| $$     /$$__  $$| $$       \____  $$             /$$  \ $$| $$  | $$| $$       | $$ /$$
|  $$$$$$/|  $$$$$$$| $$    |  $$$$$$$| $$       /$$$$$$$/            |  $$$$$$/|  $$$$$$/| $$       |  $$$$/
 \______/  \_______/|__/     \_______/|__/      |_______/              \______/  \______/ |__/        \___/  
"""

def whoami(user):
    print(f"""╔════════ USER PROFILE ════════╗
    
Name: {user['name'].capitalize()}
Birthday: {user['birthday']}
Email: {user['email']}

╚══════════════════════════════╝ """)

def check_sound(name,settings):
    if settings["sound"] == "ON":
        playsound("audio/" + name, block= False)


def aboutme(settings):
    print("""Hello my name is Jafar nad im only this programm maker and developer by the way.I will be happy if you guys,
        give more and more goods idea for improving and adding new functional,
        and new achivements!!! Thanks for everyone ^^  ver 0.0.2
        """)
    check_sound("virtualAshraf.wav", settings)

def help_menu():
    print("""
    help - show help menu
    whoami - show who are you and personal data
    settings - open current settings
    time - show time right now
    clear - cleaning terminal output
    exit - end session
    color - change color
    aboutme - info about me


    """)

def chcolor(settings):
    os.system("color 2")
    check_sound("Sci-FiClick.wav", settings)


def clear(settings):
    os.system("cls")
    check_sound("Sci-FiClick.wav", settings)


def setuser(user,data,settings):
    
    print(f"""
    Change name - 1
    Change password - 2 
    Change Email - 3
    Sound: {settings["sound"]} - 4 (for change) 
    Theme - ~~~~
    Exit - 0
"""
    )
    try:
        action = int(input("Enter your action:"))
    except ValueError:
        print("ins`t number")
        return

    if action == 1:
        newname = input("Enter your new name:")
        user["name"] = newname

    elif action == 2:
        newpass = input("Enter new password:")
        user["password"] = newpass


    elif action == 3:
        newmail = input("Enter your new Mail:")
        user["email"] = newmail

    elif action == 4:
        if settings["sound"] == "OFF":
            settings["sound"] = "ON"

        elif settings["sound"] == "ON":
            settings["sound"] = "OFF"

    with open("base.json", "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4, ensure_ascii=False)





def cmd_commands(user,data,settings):
    commands = {
    "settings": lambda: setuser(user,data,settings),
    "clear": lambda: clear(settings),
    "aboutme": lambda: aboutme(settings),
    "time": lambda: print(time.ctime()),
    "help": help_menu,
    "color": lambda: chcolor(settings),
    "whoami": lambda: whoami(user)



}
    return commands