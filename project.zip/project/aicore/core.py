import time
from typing import Dict

from .perception import Perception
from .state import AIState
from .decision import DecisionEngine
from .actions import ActionRegistry, do_nothing, log_event
from .memory import Memory
from .learning import LearningEngine
from .models import Episode, State


class AICore:
    def __init__(self, tick_interval: float = 1.0):
        self.tick_interval = tick_interval

        self.perception = Perception()
        self.state = AIState()
        self.memory = Memory()
        self.learning = LearningEngine(self.memory)

        self.actions = ActionRegistry()
        self.actions.register("do_nothing", do_nothing)
        self.actions.register("log_event", log_event)

        self.decision = DecisionEngine(self.memory, self.state)

    def tick(self) -> None:
        self.state.set(State.OBSERVING)

        facts: Dict = self.perception.perceive()

        self.state.set(State.ACTING)

        available = list(self.actions.available_actions().keys())
        action = self.decision.decide(facts, available)

        result = self.actions.execute(action)

        if action.name == "do_nothing":
            self.state.restore_energy(0.05)
        else:
            self.state.spend_energy(0.1)


        episode = Episode(
            facts=facts,
            action=action,
            result=result,
        )

        self.state.set(State.LEARNING)
        self.learning.learn(episode)
        print(f"[AI] action={action.name}, energy={self.state.energy:.2f}")

        self.state.set(State.IDLE)


    def run(self) -> None:
        while True:
            self.tick()
            time.sleep(self.tick_interval)
