from typing import Dict, Callable
from .models import Action, Result


class ActionRegistry:
    def __init__(self):
        self._actions: Dict[str, Callable[[Action], Result]] = {}

    def register(self, name: str, handler: Callable[[Action], Result]) -> None:
        self._actions[name] = handler

    def available_actions(self) -> Dict[str, Callable]:
        return self._actions

    def execute(self, action: Action) -> Result:
        handler = self._actions.get(action.name)
        if not handler:
            return Result(success=False, reward=-1.0, info={"error": "unknown_action"})
        return handler(action)

    
# --- Базовые действия ---

def do_nothing(_: Action) -> Result:
    return Result(success=True, reward=0.0, info={"note": "no_action"})


def log_event(action: Action) -> Result:
    print("LOG ACTION")
    return Result(success=True, reward=0.1, info={"logged": True})

