from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, Optional
import time


class State(Enum):
    IDLE = auto()
    OBSERVING = auto()
    ACTING = auto()
    LEARNING = auto()


@dataclass
class Fact:
    type: str
    value: Any
    confidence: float = 1.0
    timestamp: float = field(default_factory=time.time)


@dataclass
class Action:
    name: str
    params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Result:
    success: bool
    reward: float
    info: Optional[Dict[str, Any]] = None


@dataclass
class Episode:
    facts: Dict[str, Fact]
    action: Action
    result: Result
    timestamp: float = field(default_factory=time.time)
