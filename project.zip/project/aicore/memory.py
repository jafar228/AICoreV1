import json
from pathlib import Path
from collections import defaultdict, deque
from typing import Deque, Dict
from .models import Episode
class Memory:
    def __init__(self, max_episodes: int = 1000, path: str = "memory.json"):
        self.episodes: Deque[Episode] = deque(maxlen=max_episodes)
        self.action_stats: Dict[str, Dict[str, float]] = defaultdict(
            lambda: {"count": 0.0, "success": 0.0, "avg_reward": 0.0}
        )
        self.path = Path(path)
        self._load()


    def store_episode(self, episode: Episode) -> None:
        self.episodes.append(episode)
        self._update_stats(episode)

    def _update_stats(self, episode: Episode) -> None:
        name = episode.action.name
        stats = self.action_stats[name]

        stats["count"] += 1
        if episode.result.success:
            stats["success"] += 1

        # скользящее среднее награды
        c = stats["count"]
        stats["avg_reward"] += (episode.result.reward - stats["avg_reward"]) / c

    def get_action_stats(self, action_name: str) -> Dict[str, float]:
        return self.action_stats.get(
            action_name, {"count": 0.0, "success": 0.0, "avg_reward": 0.0}
        )
    
    def _load(self) -> None:
        if not self.path.exists():
            return
        data = json.loads(self.path.read_text(encoding="utf-8"))
        for name, stats in data.items():
            self.action_stats[name] = stats

    def save(self) -> None:
        self.path.write_text(
            json.dumps(self.action_stats, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

