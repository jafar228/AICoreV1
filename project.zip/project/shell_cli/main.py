from aicore.core import AICore
from aicore.models import Action, Result

# --- CLI actions ---

def active(_: Action) -> Result:
    print("[CLI] ACTIVE mode")
    return Result(success=True, reward=0.0)

def minimal(_: Action) -> Result:
    print("[CLI] MINIMAL mode")
    return Result(success=True, reward=0.0)

def silent(_: Action) -> Result:
    print("[CLI] SILENT mode")
    return Result(success=True, reward=0.0)


def main():
    core = AICore(tick_interval=0)

    # регистрируем CLI-действия
    core.actions.register("ACTIVE", active)
    core.actions.register("MINIMAL", minimal)
    core.actions.register("SILENT", silent)

    print("CLI оболочка запущена. ENTER = тик, Ctrl+C = выход")

    while True:
        input("\nENTER → следующий тик")
        core.tick()

        # вручную влияем на обучение
        try:
            r = float(input("reward (-5..5): "))
        except ValueError:
            r = 0.0

        # ⚠️ reward уже записан в Episode,
        # здесь ты просто наблюдаешь поведение


if __name__ == "__main__":
    main()
