from typing import Dict, List
from .models import Action, Fact
from .memory import Memory
from .state import AIState
import random


class DecisionEngine:
    def __init__(self, memory: Memory, state: AIState):
        self.memory = memory
        self.state = state

    def decide(self, facts, available_actions):
    # 20% — исследование
        if random.random() < 0.2:
            return Action(name=random.choice(available_actions))

        best_action = "do_nothing"
        best_score = float("-inf")
        

        for name in available_actions:
            stats = self.memory.get_action_stats(name)
            frequency_penalty = stats["count"] * 0.01
            score = stats["avg_reward"] - frequency_penalty

        # КОНТЕКСТНОЕ ПРАВИЛО
            if "heartbeat" not in facts:
                score -= 1.0

            if name != "do_nothing" and facts.get("heartbeat") is None:
                score -= 1.0

            if self.state.energy < 0.3 and name != "do_nothing":
                score -= 1.0

        # ВОТ ЧЕГО НЕ ХВАТАЛО
            if score > best_score:
                best_score = score
                best_action = name

        return Action(name=best_action)

