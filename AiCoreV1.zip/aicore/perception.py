import time
from typing import Dict
from .models import Fact


class Perception:
    def perceive(self) -> Dict[str, Fact]:
        facts: Dict[str, Fact] = {}

        # базовые факты (мир можно расширять)
        facts["time"] = Fact(
            type="time",
            value=time.time(),
            confidence=1.0,
        )

        facts["heartbeat"] = Fact(
            type="internal",
            value="alive",
            confidence=1.0,
        )

        return facts
