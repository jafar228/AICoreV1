from .models import State


class AIState:
    def __init__(self):
        self.current: State = State.IDLE
        self.energy: float = 1.0  # 0.0 — нет сил, 1.0 — максимум

    def set(self, state: State) -> None:
        self.current = state

    def get(self) -> State:
        return self.current

    def spend_energy(self, amount: float) -> None:
        self.energy = max(0.0, self.energy - amount)

    def restore_energy(self, amount: float) -> None:
        self.energy = min(1.0, self.energy + amount)
