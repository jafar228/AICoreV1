from .memory import Memory
from .models import Episode


class LearningEngine:
    def __init__(self, memory: Memory):
        self.memory = memory

    def learn(self, episode: Episode) -> None:
        self.memory.store_episode(episode)
        self.memory.save()
